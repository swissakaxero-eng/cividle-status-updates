# CivIdle Komplett-Kompendium — Stand 05.09.2026

## Datenstand und Genauigkeit
Dieses Paket kombiniert die Community-Wiki (Research-Seite zuletzt 05.07.2026, Wonders 18.07.2026, GP 04.07.2026) mit dem öffentlich sichtbaren aktuellen CivIdle-Quellcode auf GitHub. CivIdle wird aktiv verändert; einzelne Wiki-Baukosten können gegenüber dem aktuellen Source abweichen. Wo das auffiel, ist es markiert.

## Spielschleife
1. Karte erkunden.
2. Rohstoff-Deposits finden.
3. Extraktions- und Produktionsgebäude setzen.
4. Inputs per Worker-Transport zuführen.
5. Arbeiter beschäftigen -> Science.
6. Technologien erforschen -> Gebäude, Systeme, Multiplikatoren.
7. Zeitalter betreten -> GP-Auswahl.
8. Empire Value steigern.
9. Rebirth -> Current-GPs werden Shards; permanente GP/Age-Wisdom ausbauen.
10. Wiederholen und höhere EV-/GP-/Wonder-/Endgame-Schwellen erreichen.

## Karte / lokale Karte
- Hexfelder.
- Viele Extraktoren benötigen das passende Deposit.
- Gebäude haben Sichtweite; der aktuelle Source definiert eine Standard-Sichtweite von 2.
- Statistics Office erzeugt Explorer; Forschungen erhöhen Explorer-Reichweite.
- Nachbarschaften sind spielentscheidend, weil zahlreiche Wonders Effekte auf angrenzende bzw. 2-Tile-Bereiche geben.
- Wasser, Deposits und Natural Wonders verändern optimale Layouts.
- Hatshepsut Temple kann Wasser aufdecken; Great Mosque of Samarra kann Deposits aufdecken und Level-10-Extraktoren erzeugen.
- Cartographer wird über Exploration freigeschaltet.

## World Map
- Separat von der lokalen Produktionskarte.
- Wird für Player Trading via Caravansary genutzt.
- Beim ersten Caravansary wird ein World-Map-Tile beansprucht.
- Handelsrouten/Tarife können Belohnungen erzeugen.
- Spätere Technologien erlauben Handel über das Meer.
- WTO/UN führen serverweite wöchentliche Abstimmungsmechaniken ein.

## Bauzeit
Normale Gebäude besitzen praktisch keine für alle Runs identische feste Sekunden-Bauzeit. Die effektive Bauzeit wird durch:
- benötigte Ressourcen,
- vorhandene Bestände,
- Produktionsraten,
- Transportwege,
- freie Worker,
- Transport Capacity,
- Builder Capacity,
- Prioritäten,
- Wonder-Bauprojekte
bestimmt. Deshalb ist eine universelle 'Gebäude X = 30 Sekunden'-Liste nicht korrekt.

## Upgrade-Verhalten
Community-Wiki: nächste Upgrade-Kosten wachsen je Level ×1,5.
Für ein Basisgebäude C:
L1 = C, L2 = 1,5C, L3 = 2,25C ...
Upgrades erhöhen Basisproduktion, Basisverbrauch und Basislager. Ein höheres einzelnes Gebäude benötigt gegenüber mehreren separaten Gebäuden weniger zusätzliche Happiness-Slots.

Die CSV 05 enthält die generische Kurve bis Level 100; CSV 07 konkrete Beispiele bis Level 50.

## Transport
- Ressourcen werden vom konsumierenden Gebäude 'gezogen'.
- Distanz erhöht Worker-Bedarf.
- Transport Capacity pro Worker reduziert die Anzahl nötiger Transportarbeiter.
- Land Trade und Railway geben jeweils +1 Transport Capacity.
- Empress Wu Zetian gibt +1 Transport Capacity Multiplier.
- Warehouse/Caravansary/Market werden durch mehrere Techs und Port of Singapore stark verbessert.
- Building Transport Preference und Stockpile Mode werden früh im Bronze Age freigeschaltet.

## Worker Capacity
Worker Capacity Multipliers senken den Personalbedarf der Produktion/Logistik relativ zur Leistung.
Temple of Heaven bufft Level>=10-Gebäude.
Marina Bay Sands gibt global +5 und +1 je weiterem Wonder-Level.

## Storage
- Jedes Produktionsgebäude besitzt eigenen Speicher.
- Warehouse hat sehr großen allgemeinen Speicher.
- Storage Multipliers werden durch Technologien, GPs, Wonders und Level verstärkt.
- Information-Age ISS gibt global +5 Storage und +1 pro Upgrade.
- Mehrere Techs geben +100% Base Storage für Market/Warehouse/Caravansary.

## Science
- Standard: 1 Science pro Busy Worker.
- Idle Worker: standardmäßig 0.
- Techs, GPs und Wonders addieren Science pro Worker.
- University-Tech +1 busy.
- Journalism +1 busy.
- Luxor +1 busy.
- Big Ben +2 busy.
- Beispiele GPs: Socrates +1 busy, Darwin +2 busy, Turing +3 idle, Galileo +1 idle, Fibonacci +1 busy/+0.5 idle, Niels Bohr +3 all workers bei >50% busy.
- Matrioshka Brain: +5 busy und idle; Science zählt zu EV (5 Science = 1 EV).

## Happiness
- Gebäude belasten Happiness; deshalb ist Upgrading oft effizienter als massenhaft neue L1-Gebäude.
- Aristophanes +1; Rurik +2; Florence Nightingale +3.
- Olympics-Tech +5.
- Hagia Sophia +5.
- Alderson Disk +25 und +5 je Upgrade.
- Space Needle +1 pro gebautem Wonder.

## Market
- AI-Handel.
- Marktpaare resetten ungefähr alle 60 Minuten.
- Nur freigeschaltete Ressourcen.
- Wechselverhältnis basiert auf Resource Value plus zufälligem Spread.
- Nutzzwecke: Engpässe abfedern, Nebenprodukte entsorgen, Wonder-Ressourcen besorgen, EV-Arbitrage.

## Caravansary
- Handel mit echten Spielern.
- World-Map-Tile muss beansprucht werden.
- Ressourcen müssen physisch in das Gebäude transportiert werden.
- World-Map-Position/Tarife können Handelsbelohnungen beeinflussen.

## Statistics Office — was auslesbar ist
Empire-Tab:
- Empire Value
- Science Production
- Transportation
- Exploration

Resources-Tab:
- aktueller Bestand jeder freigeschalteten Ressource
- Empire Value
- Deficit/Surplus
- geschätzte Run-Out-Zeit
- Watched Resources für HUD

Buildings-Tab:
- Level
- Empire Value
- Worker in Transport
- Worker in Produktion
- Electrification Level (wo anwendbar)

## Tutorials / empfohlene Lernreihenfolge
1. Startforschungen und erste Rohstoffe.
2. Brick/Lumber/Wheat stabilisieren.
3. Statistics Office früh bauen.
4. Population nie isoliert maximieren: Worker müssen produktiv/transportfähig sein.
5. Lagerdefizite und Run-Out-Werte beobachten.
6. Bronze: Priority, Transport Preference, Stockpile Mode lernen.
7. Iron: Warehouse + Caravansary + Transport Capacity.
8. Classical/Middle: Autopilot, Builder Capacity, Happiness/Wonder-Auren.
9. Renaissance/Industrial: Level>=10-Synergien, Elektrifizierung, Markets, lange Ketten.
10. World Wars/Cold War: Nuklear-, Medien-, Raumfahrt- und Globalhandelssysteme.
11. Information/Future: globale Wonder-Multiplikatoren und GP-Endgame.

## Rebirth
- Techbaum wird neu durchlaufen.
- Current GPs werden zu Shards.
- Permanente GP-Level + Age Wisdom bilden die langfristige Progression.
- Extra-GP-Schwelle: 64M × n³ EV.
- Höherer EV vor Rebirth = mehr GP-Auswahlen, aber längeres Warten hat Opportunitätskosten.

## Great-People-Stapelung
Gesamtbonus eines normalen GPs ist näherungsweise:
(Current-Run-Harmonic-Summe) + Permanent-Level + Age-Wisdom-Level.
Beispiel: Sargon einmal im Run (+1), permanent L5 (+5), Bronze Wisdom 3 (+3) => +9 Production und +9 Storage auf seine Zielgebäude.
Zweite Auswahl desselben GPs im Run addiert typischerweise nur +0,5 des Basisbonus, dritte +0,333 usw.

## Dateien in diesem Paket
- 01_Forschungen.csv — kompletter dokumentierter Techbaum bis Future.
- 02_Great_People.csv — vollständig dokumentierte GP-Liste der Wiki bis World Wars.
- 03_GP_und_Age_Wisdom.md — Formeln und Erklärung.
- 04_EV_Extra_GP_Schwellen.csv — EV-Schwellen 1–50.
- 05_Upgrade_Skalierung_generisch.csv — Kosten-/Level-Skalierung bis L100.
- 06_Gebaeude_Basiswerte.csv — verifizierte Basiswerte/Kerngebäude.
- 07_Gebaeude_Upgrade_Beispiele_bis_L50.csv — Beispiel-Levelkurven.
- 08_Wonders.csv — Wonder-Kosten und Effekte.
- 09_Komplettguide.md — diese Erklärung.
- 10_Quellen.txt — Primär-/Community-Quellen.

## Wichtige Einschränkung
'Alles' in CivIdle ist größer als die aktuelle Community-Dokumentation. Der offene Source enthält deutlich mehr Definitionen als die Wiki (BuildingDefinitions.ts >2500 Zeilen, GreatPersonDefinitions.ts >2200, TechDefinitions.ts >850, UpgradeDefinitions.ts >900). Dieses Paket enthält alle in der Recherche zuverlässig extrahierten aktuellen Daten sowie die vollständig dokumentierten Forschungen. Zahlen, die in Wiki und aktuellem Source widersprüchlich waren, wurden nicht erfunden.
