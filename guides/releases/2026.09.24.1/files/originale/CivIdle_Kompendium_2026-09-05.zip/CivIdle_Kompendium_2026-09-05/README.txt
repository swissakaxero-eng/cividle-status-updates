CivIdle-Kompendium, Stand 05.09.2026

Starte mit 09_Komplettguide.md.
Für Forschung: 01_Forschungen.csv.
Für GPs/Age Wisdom: 02 + 03.
Für Upgrade-Kurven: 05 + 07.
Für Wonders: 08.

Hinweis: CivIdle ist aktiv in Entwicklung. Dieses Paket trennt dokumentierte Fakten von Stellen, an denen Wiki und aktueller Source voneinander abweichen.
