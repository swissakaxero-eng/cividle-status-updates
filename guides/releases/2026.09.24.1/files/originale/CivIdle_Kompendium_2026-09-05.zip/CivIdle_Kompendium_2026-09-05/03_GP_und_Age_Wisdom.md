# Great People, Shards, permanente Level und Age Wisdom

## Grundprinzip
Die wirksamen Boni stapeln sich aus:
**Current Run GP + Permanent GP + Age Wisdom**.

Ein GP kann im selben Run mehrfach gewählt werden. Für die meisten GPs folgt die Zusatzwirkung ungefähr:
erste Wahl = 1× Basisbonus, zweite = 1/2×, dritte = 1/3×, vierte = 1/4× usw.

Beim Rebirth werden Current-Run-GPs in GP-Shards des jeweiligen Charakters umgewandelt.

## Permanente GP-Level
Normale permanente Upgrade-Kosten: 1, 2, 4, 8, 16, ... Shards.
Jedes permanente Level gibt erneut den vollen Basisbonus des GPs.
Ausnahme: Fibonacci nutzt eine Fibonacci-artige Kostenfolge.

## Age Wisdom / Altersweisheit
Age Wisdom wirkt auf **alle Great People eines Zeitalters gleichzeitig**.
Kosten pro Wisdom-Level: 1, 3, 7, 15, 31, 63, ... = 2^Level - 1 Shards.
Der Wisdom-Level addiert denselben Basisbonus-Level auf die GPs des Zeitalters.
Beispiel: Sargon Basis +1 Prod/+1 Storage. Current=1, Permanent=5, Bronze Wisdom=3 -> insgesamt +9 Prod und +9 Storage auf seine Zielgebäude.

## Extra-GP durch Empire Value
Schwelle für den n-ten Extra-GP: **64.000.000 × n³ EV**.
