# Offizielle Links

Geprüft am 21. September 2026. Produktfunktionen, Preise und Installationswege können sich ändern; im Zweifel ist die jeweils verlinkte offizielle Dokumentation verbindlich.

## OpenAI / Codex

- Codex CLI: https://developers.openai.com/codex/cli
- Codex-Anmeldung: https://developers.openai.com/codex/auth
- Codex SDK: https://developers.openai.com/codex/sdk
- Codex Windows-App: https://developers.openai.com/codex/windows/windows-app
- Codex IDE-Erweiterung: https://developers.openai.com/codex/ide
- Codex GitHub-Repository: https://github.com/openai/codex
- Codex-Preise: https://chatgpt.com/codex/pricing/

Bestätigte Kernaussagen:

- Codex CLI kann ein lokales Repository untersuchen, bearbeiten und vorhandene Werkzeuge/Tests ausführen.
- Anmeldung ist per ChatGPT oder API-Key möglich.
- API-Key-Nutzung wird nutzungsabhängig über die API abgerechnet.
- Das Codex SDK kann lokale Codex-Threads starten und fortsetzen.

## GitHub

- Fine-grained Personal Access Tokens: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens
- Token-Einstellungen: https://github.com/settings/personal-access-tokens
- Token-Berechtigungen: https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens
- GitHub Desktop: https://desktop.github.com/
- Git for Windows: https://git-scm.com/download/win

Bestätigte Kernaussage: Fine-grained Tokens lassen sich auf bestimmte Repositorys und einzelne Berechtigungen begrenzen und sind deshalb klassischen, sehr breit berechtigten Tokens vorzuziehen, sofern der Anwendungsfall unterstützt wird.

## Claude Code

- Quickstart: https://code.claude.com/docs/en/quickstart
- Übersicht: https://code.claude.com/docs/en/overview

Bestätigte Kernaussagen:

- Windows wird unterstützt.
- Die offizielle Anleitung nennt einen nativen Installer und WinGet.
- Claude Code kann Repositorys untersuchen, Code bearbeiten und Entwicklungsbefehle ausführen.

## Cursor

- Cloud Agents: https://cursor.com/docs/cloud-agent
- GitHub-Integration: https://cursor.com/docs/integrations/github
- Worktrees: https://cursor.com/docs/configuration/worktrees

Bestätigte Kernaussagen:

- Cloud Agents arbeiten in isolierten VMs.
- Sie können Repositorys klonen, Abhängigkeiten nutzen, Tests ausführen und Änderungen auf getrennten Branches zurückgeben.
- Worktrees halten parallele Aufgaben voneinander getrennt.

## Grundprogramme

- Python: https://www.python.org/downloads/windows/
- Node.js: https://nodejs.org/en/download
- Git for Windows: https://git-scm.com/download/win

Für den vorhandenen CivIdle-Server gilt weiterhin: keine neue Installation in bestehende Projektbereiche und keine Änderung der Sicherheitsrichtlinien ohne ausdrückliche Freigabe.

