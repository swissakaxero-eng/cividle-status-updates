# Kurzer Einrichtungsguide

## 1. Codex als Hauptentwickler verwenden

Offizielle Einstiege:

- Codex CLI: https://developers.openai.com/codex/cli
- Anmeldung: https://developers.openai.com/codex/auth
- Windows-App: https://developers.openai.com/codex/windows/windows-app
- Open-Source-Repository: https://github.com/openai/codex

### Variante A – bereits in ChatGPT Work/Codex arbeiten

Das ist für die jetzige Projektarbeit am einfachsten. Repository oder Arbeitsordner öffnen, zuerst die Übergabedateien lesen lassen und Änderungen nur auf einem eigenen Branch vornehmen.

### Variante B – Codex CLI auf dem Windows-Server

Wenn Node.js/npm bereits sauber installiert sind:

```powershell
npm install -g @openai/codex
codex --version
codex login
```

Dann in den **dafür freigegebenen Projektordner** wechseln und `codex` starten. Bei einer frischen Windows-Installation zuerst die aktuelle offizielle Windows-Anleitung prüfen; Installationswege ändern sich gelegentlich.

Für die Anmeldung bevorzugt **„Sign in with ChatGPT“**, sofern der gewünschte Funktionsumfang im Abo enthalten ist. Ein API-Key verursacht separat nutzungsabhängige API-Kosten.

## 2. GitHub als zentrale Wahrheit

Projekt:

- https://github.com/swissakaxero-eng/cividle-bot-private

GitHub-Dokumentation:

- Fine-grained Tokens: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens
- Token-Einstellungen: https://github.com/settings/personal-access-tokens

Empfohlene Regeln:

- Zugriff nur auf `swissakaxero-eng/cividle-bot-private`;
- minimale Rechte;
- Ablaufdatum setzen;
- Token niemals in Chat, Logs, ZIPs oder Repository-Dateien kopieren;
- wenn möglich Browser-Anmeldung oder Git Credential Manager statt eines manuell gespeicherten Tokens;
- jede Aufgabe auf eigenem Branch;
- Merge erst nach Tests und Review.

Typische Mindestberechtigungen für einen Agenten, der Code und Pull Requests verwalten soll:

| Berechtigung | Einstellung |
|---|---|
| Repository access | Nur das CivIdle-Repo |
| Metadata | Read |
| Contents | Read and write |
| Pull requests | Read and write, falls PRs verwendet werden |

Je nach verwendeter GitHub-Funktion können weitere Rechte nötig sein. Nur gezielt ergänzen, wenn eine konkrete Funktion sonst nicht läuft.

## 3. Headless-Bereich getrennt halten

Vorgesehener Bereich:

```text
C:\CivIdle_Headless
├─ app
├─ benchmarks
├─ configs
├─ datasets
├─ logs
├─ results
├─ strategies
└─ validation
```

Der Simulator schreibt nur in diesen Bereich. Er öffnet, kopiert oder verändert keinen echten Main-Save.

Erster reproduzierbarer Test:

```text
Welten: 1 / 2 / 4
Schritte je Welt: 600
gleiche Konfiguration
feste Seeds
gleiche Programmversion
Hardware- und Zeitmessung mitschreiben
```

## 4. Codex SDK erst später

Offizielle Dokumentation:

- https://developers.openai.com/codex/sdk

Installation für eine spätere TypeScript-Orchestrierung:

```powershell
npm install @openai/codex-sdk
```

Erst einsetzen, wenn:

- Tests stabil sind;
- Benchmarks reproduzierbar sind;
- Ergebnisdateien ein festes Schema haben;
- der Agent Änderungen sicher zurücksetzen kann;
- klare Kosten- und Laufzeitgrenzen existieren.

## 5. Claude Code optional als Zweitprüfer

Offizielle Anleitung:

- https://code.claude.com/docs/en/quickstart

Offizielle Windows-Optionen umfassen unter anderem WinGet:

```powershell
winget install Anthropic.ClaudeCode
claude --version
claude
```

Empfohlene Nutzung: zuerst nur Review, eigener Branch oder read-only Checkout, keine gleichzeitigen Änderungen mit Codex.

## 6. Cursor Cloud Agents optional

Offizielle Dokumentation:

- Cloud Agents: https://cursor.com/docs/cloud-agent
- Worktrees: https://cursor.com/docs/configuration/worktrees

Cursor ist sinnvoll, wenn mehrere getrennte Aufgaben gleichzeitig laufen sollen. Jeder Agent braucht eine eigene isolierte Umgebung bzw. einen eigenen Branch. Für den jetzigen Stand ist es kein Muss.

## 7. Keine unnötige Installation

Nicht alles gleichzeitig einrichten. Die vernünftige Reihenfolge lautet:

```text
GitHub-Stand sauber
→ Codex-Arbeitsweise festlegen
→ Headless-Benchmark stabil
→ Modell gegen echtes Spiel kalibrieren
→ automatische Strategietests
→ Codex SDK
→ optional Claude/Cursor
```

