# Werkzeugvergleich für CivIdle

## Rangfolge nach Nutzen für dieses Projekt

| Werkzeug | Hauptaufgabe | Stärke | Grenze | Priorität |
|---|---|---|---|---:|
| CivIdle Headless | Schnelle Simulation und Strategievergleich | Sehr viele Läufe ohne Grafik | Nur so korrekt wie das Modell | Höchste |
| Codex in ChatGPT/App/CLI | Repo lesen, ändern, testen, auswerten | Schliesst Code-Test-Schleife | Benötigt klare Grenzen und gute Tests | Sehr hoch |
| GitHub | Versionen, Branches, Reviews, Übergaben | Verbindliche Projektquelle | Führt selbst keine Optimierung aus | Sehr hoch |
| ChatGPT | Architektur, Entscheidungen, Erklärungen | Gesamtüberblick und Zusammenarbeit | Normaler Chat allein ist bei vielen Dateien langsam | Hoch |
| Codex SDK | Automatisierte Coding-Schleifen | Programmatisch start- und fortsetzbare Agentenläufe | Erst sinnvoll, wenn Tests zuverlässig sind | Später hoch |
| Claude Code | Unabhängige Zweitprüfung | Andere Analyseperspektive | Zusätzliche Kosten und Koordination | Mittel/optional |
| Cursor Cloud Agents | Viele getrennte Cloud-Aufträge | Isolierte VMs/Branches und Parallelität | Mehr Systemkomplexität und Kosten | Optional |

## Warum ein anderes LLM allein wenig ändert

Ein stärkeres oder anderes Modell kann einzelne Analysen verbessern. Es löst aber nicht automatisch:

- manuelle ZIP-Übergaben;
- fehlende reproduzierbare Benchmarks;
- nicht versionierte Ergebnisse;
- uneinheitliche Startzustände;
- Unterschiede zwischen Server- und Testaccount;
- langsame echte UI-Läufe;
- fehlende automatische Entscheidung, ob eine Änderung wirklich besser ist.

Der grosse Sprung entsteht durch eine geschlossene Schleife:

```text
Änderung erzeugen
→ Tests ausführen
→ Headless-Benchmark ausführen
→ Ergebnis statistisch bewerten
→ besser: behalten / schlechter: verwerfen
→ nächsten Kandidaten erzeugen
```

## Empfohlene Rollen

### ChatGPT/Codex: Chefentwickler

- liest `project/START.md` und `project/HANDOFF_LATEST.json`;
- ändert Code in einem eigenen Branch;
- führt Tests aus;
- erklärt Abweichungen;
- dokumentiert Entscheidungen;
- erstellt keine unkontrollierten Serveränderungen.

### Headless-Simulator: Versuchslabor

- simuliert Entscheidungen ohne Bildschirm;
- testet Seeds und Parameter;
- vergleicht Strategien schneller als Echtzeit;
- erzeugt strukturierte Resultate;
- darf niemals als Beweis für reale Laufzeit oder reale Stabilität missverstanden werden.

### Echter Spielbot: Prüfstand

- überprüft die besten simulierten Kandidaten;
- misst `full_cycle_sec` im echten Spiel;
- findet UI-/Erkennungsprobleme;
- entscheidet zusammen mit Stabilitätstests, ob eine Strategie produktionsreif ist.

### Zweitprüfer: Claude oder separater Codex-Lauf

- prüft Änderungen zunächst read-only;
- sucht Logikfehler, Datenleckage, falsche Annahmen und Race Conditions;
- darf nicht gleichzeitig denselben Branch verändern.

## Was aktuell nicht nötig ist

- neues grosses Cloud-System nur wegen eines Modellnamens;
- mehrere Agenten auf demselben Branch;
- automatische Übernahme eines schnelleren Einzelruns;
- Zugriff des Simulators auf den echten Main-Save;
- ungeprüfte Selbständerung des laufenden Bots;
- Autostart oder Updater während der Erprobungsphase.

