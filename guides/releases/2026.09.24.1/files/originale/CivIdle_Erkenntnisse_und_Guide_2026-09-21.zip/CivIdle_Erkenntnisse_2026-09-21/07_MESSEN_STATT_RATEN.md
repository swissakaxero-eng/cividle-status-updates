# Messen statt raten

## Kernmetriken

### Simulatorleistung

- `wall_clock_sec`
- `cpu_time_sec`
- `steps_per_sec`
- `worlds_per_min`
- `peak_rss_mb`
- `startup_sec`
- `serialization_sec`
- `error_count`

### Fachliche Qualität

- Endzustand pro Seed;
- Ressourcen/Produktion an Checkpoints;
- erreichte Meilensteine;
- ungültige Aktionen;
- Invariantverletzungen;
- Abweichung zum realen Referenzlauf;
- Strategie-Score pro Profil.

### Echter Bot

- `full_cycle_sec`;
- Erfolgs-/Fehlerrate;
- Recovery-Anzahl;
- Erkennungsfehler;
- falsche Klicks;
- Wartezeitanteil;
- Stabilität 3/3 und 20/20.

## Ein fairer Vergleich benötigt

- gleichen Commit;
- gleiche Abhängigkeiten;
- gleiche Hardware bzw. klare Kennzeichnung;
- gleiche Seeds;
- gleiche Profile;
- gleiche Schrittzahl/Zielbedingung;
- gleiche Logging-Stufe;
- getrennten Warm-up;
- mehrere Wiederholungen;
- Median statt nur Bestwert.

## Entscheidungsregel für Codeoptimierungen

Eine Änderung gilt nur dann als besser, wenn:

1. alle fachlichen Tests bestehen;
2. keine Sicherheits-/Pfadregel verletzt wird;
3. das Ergebnis reproduzierbar ist;
4. der Vorteil grösser als das Messrauschen ist;
5. keine wichtige Nebenmetrik unvertretbar schlechter wird;
6. der Bericht Commit, Konfiguration und Rohdaten enthält.

## Entscheidungsregel für Strategien

Nicht nur Geschwindigkeit maximieren. Sinnvolle Zielfunktion:

```text
Score = Laufzeit
      + Fehlerstrafe
      + Instabilitätsstrafe
      + Regelverletzungsstrafe
      + Profil-Überanpassungsstrafe
```

Eine Strategie, die im Mittel minimal langsamer, aber deutlich stabiler ist, kann für den echten Bot besser sein.

## Typische Messfehler

- nur den schnellsten Lauf melden;
- unterschiedliche Seeds vergleichen;
- Debug-Logging nur bei einem Kandidaten aktivieren;
- Simulationszeit mit realer Spielzeit verwechseln;
- einen Kandidaten auf demselben Datensatz erzeugen und bewerten;
- ungültige Aktionen still ignorieren;
- den Champion nach jedem Zufallslauf ersetzen;
- Parallelität ohne CPU-/RAM-Messung erhöhen;
- Verbesserung behaupten, obwohl sie innerhalb der Streuung liegt.

## Empfohlenes Ergebnisformat

```json
{
  "schema_version": 1,
  "run_id": "eindeutige-id",
  "commit": "git-commit",
  "config_hash": "sha256",
  "profile": "profile-name",
  "seed": 12345,
  "worlds": 4,
  "steps_per_world": 600,
  "wall_clock_sec": 0.0,
  "steps_per_sec": 0.0,
  "peak_rss_mb": 0.0,
  "valid": true,
  "violations": [],
  "metrics": {},
  "created_utc": "ISO-8601"
}
```

## Stufenmodell für Kandidaten

| Stufe | Prüfung | Ausgang |
|---|---|---|
| 0 | Syntax/Schema | ungültige Kandidaten weg |
| 1 | Unit-/Invarianttests | fachlich falsche Kandidaten weg |
| 2 | kurzer Headless-Lauf | sehr schlechte Kandidaten weg |
| 3 | Multi-Seed-Benchmark | instabile Kandidaten weg |
| 4 | mehrere Profile | Überanpassung erkennen |
| 5 | 3 echte Runs | realer Screening-Vergleich |
| 6 | 20 echte Runs | Produktionsfreigabe |

