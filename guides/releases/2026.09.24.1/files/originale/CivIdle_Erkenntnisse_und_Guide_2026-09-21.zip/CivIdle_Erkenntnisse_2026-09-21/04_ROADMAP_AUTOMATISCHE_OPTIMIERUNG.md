# Roadmap zur automatischen CivIdle-Optimierung

## Phase 0 – Schutz und Reproduzierbarkeit

Ziel: Jeder Lauf ist erklärbar und wiederholbar.

- Ordnergrenzen erzwingen.
- Version/Commit-ID in jedes Ergebnis schreiben.
- Konfiguration vollständig mitspeichern.
- feste Seeds unterstützen.
- Hardware, Start-/Endzeit und Laufdauer erfassen.
- Abbruchgrenzen für Zeit, Speicher und Fehler festlegen.
- keine Verbindung zum echten Main-Save.

Abnahme: Derselbe Commit mit derselben Konfiguration und demselben Seed erzeugt denselben fachlichen Endzustand.

## Phase 1 – Referenz-Benchmark

Ziel: Ausgangsleistung messen.

- 1, 2 und 4 parallele Testwelten;
- je 600 Schritte;
- Warm-up getrennt ausweisen;
- mindestens mehrere Wiederholungen;
- Median und Streuung ausgeben;
- CPU-/RAM-Nutzung erfassen;
- Ergebnis als JSON plus menschenlesbaren Bericht speichern.

Abnahme: Ein Referenzbericht benennt die schnellste stabile Konfiguration und zeigt, ob Parallelität wirklich Nutzen bringt.

## Phase 2 – Fachliche Validierung

Ziel: Der Simulator bildet CivIdle genügend genau ab.

- Kostenformeln;
- Produktionsformeln;
- Lager/Transport;
- Freischaltungen;
- Forschung;
- Great Persons;
- Alter/Rebirth;
- Rundung und Tick-Reihenfolge;
- Grenzfälle und ungültige Aktionen.

Abnahme: Eine Abweichungstabelle zeigt bekannte Differenzen zum realen Spiel. Kritische Differenzen sind null oder ausdrücklich blockierend.

## Phase 3 – Parametrische Strategien

Ziel: Der Simulator kann Varianten statt hart codierter Einzelstrategien testen.

Beispiele:

- Anzahl Gebäude pro Welle;
- Prioritäten für Holz, Forschung und Bevölkerung;
- Mindestlagerstände;
- Bau-/Upgrade-Schwellen;
- GP-Prioritäten;
- Bronze-/Eisenzeit-Meilensteine;
- Risiko- und Sicherheitsreserven.

Abnahme: Jede Strategie ist als Datenobjekt speicherbar, vergleichbar und wiederholbar.

## Phase 4 – Mehrstufige Suche

Ziel: Rechenzeit auf vielversprechende Kandidaten konzentrieren.

1. Grobes Screening mit wenigen Seeds/Schritten.
2. Gute Kandidaten mit mehr Seeds.
3. Finalisten mit vollständigen Läufen.
4. Champion gegen bisherigen Champion.
5. Nur belastbare Verbesserungen in die Kandidatenliste übernehmen.

Mögliche Suchverfahren:

- Raster-/Zufallssuche als Baseline;
- evolutionäre Suche;
- Bayesian Optimization für teure Parameter;
- Bandit/Successive Halving zum frühen Verwerfen;
- lokale Suche um den aktuellen Champion;
- später Reinforcement Learning nur bei klar definiertem Zustands-/Aktionsraum.

Wichtig: Ein kompliziertes KI-Verfahren ist nicht automatisch besser. Zuerst einfache Suchverfahren als überprüfbare Baseline.

## Phase 5 – Realitätsprüfung

Ziel: Simulatorerfolg in echte Botleistung übersetzen.

- nur Top-Kandidaten exportieren;
- zuerst einzelne kontrollierte Realtests;
- dann exakt 3 Screening-Runs;
- nur 3/3 stabile Kandidaten vergleichen;
- niedrigerer Median `full_cycle_sec` gewinnt;
- Sieger anschliessend 20 Runs;
- 20/20 stabil für Produktionsfreigabe;
- bei UI-Fehlern Kandidat oder Erkennung zurückstufen.

Diese Regeln entsprechen der bisherigen CivIdle-Benchmarklogik und verhindern, dass ein Glückslauf gewinnt.

## Phase 6 – Entwicklungsagent

Ziel: Codeverbesserungen kontrolliert automatisieren.

```text
Issue auswählen
→ eigenen Branch/Worktree erstellen
→ Codex ändert Code
→ Unit-/Integrations-/Invarianttests
→ Headless-Benchmark
→ unabhängiges Review
→ besser und korrekt?
  → Ja: PR zur Freigabe
  → Nein: Branch verwerfen, Befund behalten
```

Kein Agent merged selbständig in `main`, solange Tests, Kostenkontrolle und Rückfallstrategie nicht nachweislich ausgereift sind.

## Phase 7 – Langläufer

Ziel: sichere Nacht-/Langläufe.

- feste Zeit-/Kosten-/CPU-/RAM-Limits;
- Checkpoints;
- Heartbeat/Statusdatei;
- sauberer Abbruch;
- keine Endlosschleife ohne Budget;
- Ergebnisse append-only;
- eindeutige Run-ID;
- Neustart ohne Doppelwertung;
- Report am Ende, auch bei Teilfehlern.

## Was zuerst optimiert werden sollte

1. Profiling: tatsächliche Hotspots messen.
2. Datenkopien und Serialisierung reduzieren.
3. Batch-Verarbeitung statt Kleinstaufrufe.
4. deterministische Kernlogik von Logging/IO trennen.
5. Parallelität erst nach Messung wählen.
6. Native Beschleunigung nur für belegte Hotspots.
7. Caching nur mit klarer Gültigkeit.

Mehr parallele Welten sind nicht automatisch schneller. Ab einem Punkt begrenzen CPU-Kerne, Speicherbandbreite, Prozessstart und Ergebniszusammenführung.

