# Sicherheit und strikte Trennung

## Verbindliche Projektgrenzen

Der Headless-Testbereich ist vollständig vom laufenden Spielbot und vom echten Main-Save getrennt.

Erlaubter Zielbereich:

```text
C:\CivIdle_Headless
```

Die vorhandene RemoteBridge darf nur im Rahmen einer ausdrücklich erteilten, begrenzten Freigabe verwendet werden. Technisch unvermeidbare Auftrags-/Statusdateien in ihrem bestehenden Bereich sind von eigentlichen Headless-Ergebnissen zu unterscheiden.

## Nicht erlaubt

- laufenden Spielbot stoppen oder verändern;
- bestehende Dateien, Tasks, Prozesse, Konfigurationen oder Logs bearbeiten oder löschen;
- etwas in `CivIdle_Entwicklung` installieren, wenn dies nicht ausdrücklich separat freigegeben wurde;
- echten Main-Save öffnen, kopieren oder verändern;
- Updater einrichten;
- Autostart einrichten;
- Main-Snapshot anlegen;
- PowerShell-Sicherheitsrichtlinien umgehen;
- API-Schlüssel, Tokens oder Zugangsdaten in Reports/ZIPs schreiben;
- ungeprüft auf `main` mergen.

## Sichere Arbeitsweise

- Vor jedem Schreibzugriff Zielpfad exakt prüfen.
- Neue Dateien ausschliesslich im freigegebenen Headless-Bereich erzeugen.
- Ergebnisse niemals in bestehende Bot-Logs mischen.
- Keine rekursiven Löschbefehle auf breiten Pfaden.
- Temporäre Daten in einem eindeutigen Run-Unterordner.
- Jede Änderung mit Commit-ID und Prüfsumme kennzeichnen.
- Bei unklarer Auswirkung abbrechen und Freigabe verlangen.

## Zugangsdaten

- Bevorzugt Browser-/Geräteanmeldung oder sicheren Credential Manager verwenden.
- Fine-grained GitHub Token nur für das CivIdle-Repo.
- Minimale Rechte und Ablaufdatum.
- Keine Zugangsdaten in `.env`, Logs oder ZIP aufnehmen, sofern eine Datei ins Repository gelangen könnte.
- Falls doch Umgebungsvariablen gebraucht werden: nur Prozess-/Systemkonfiguration, nie hart codieren.
- Ein versehentlich veröffentlichter Schlüssel gilt als kompromittiert und muss sofort widerrufen/rotiert werden.

## Agenten und Branches

- ein Auftrag = ein Branch oder Worktree;
- niemals zwei schreibende Agenten gleichzeitig auf demselben Branch;
- Review-Agent zuerst read-only;
- keine automatische Produktionsfreigabe nur wegen grüner Unit-Tests;
- Benchmarkdaten und Codeänderung gemeinsam referenzieren;
- Merge durch bewusstes Freigabe-Gate.

## Kostenkontrolle

- ChatGPT-Abo und API-Abrechnung sind getrennt zu betrachten;
- API-Key-Nutzung kann zusätzliche nutzungsabhängige Kosten erzeugen;
- Claude und Cursor können eigene Abos/Verbrauchskosten verursachen;
- vor autonomen Langläufen Tages-/Run-Budget definieren;
- maximale Agentenschritte und Retry-Anzahl festlegen;
- bei wiederholtem gleichen Fehler abbrechen statt endlos weiterzurechnen.

