# Kopierbare Auftragsvorlagen

## A. Sicherer erster Codex-Auftrag

```text
Lies zuerst project/START.md und project/HANDOFF_LATEST.json sowie alle dort
direkt verlinkten aktuellen Übergaben. Fasse danach den belegten Ist-Stand kurz
zusammen.

Arbeite nur im dafür freigegebenen Branch und im Headless-Projekt. Verändere
oder stoppe den laufenden Spielbot nicht. Öffne, kopiere oder verändere keinen
echten Main-Save. Richte keinen Updater, Autostart oder Main-Snapshot ein.

Führe zuerst vorhandene Tests unverändert aus. Dokumentiere Befehl, Commit-ID,
Ergebnis und alle Fehler. Nimm noch keine Codeänderung vor, bis der Ausgangsstand
reproduzierbar ist.
```

## B. Referenz-Benchmark

```text
Führe den vereinbarten Headless-Referenzbenchmark mit 1, 2 und 4 Testwelten und
jeweils 600 Schritten aus. Verwende feste, dokumentierte Seeds und dieselbe
Konfiguration. Messe Warm-up getrennt, Laufzeit, Welten/Minute, Schritte/Sekunde,
CPU und RAM. Wiederhole jede Konfiguration ausreichend oft und berichte Median,
Minimum, Maximum und Streuung.

Speichere Rohdaten als JSON/CSV und einen menschenlesbaren Bericht ausschliesslich
unter C:\CivIdle_Headless. Verändere nichts ausserhalb dieses Bereichs, abgesehen
von technisch unvermeidbaren bestehenden RemoteBridge-Auftrags-/Statusdateien.
```

## C. Profiling ohne vorschnelle Optimierung

```text
Profile den langsamsten repräsentativen Benchmark. Nenne die zehn grössten
gemessenen Hotspots mit Zeitanteil und Aufrufzahl. Unterscheide Rechenzeit,
Serialisierung, Logging, Prozesskommunikation und Dateizugriffe. Schlage kleine,
messbare Änderungen vor. Implementiere noch nichts, dessen Nutzen nicht aus dem
Profiling ableitbar ist.
```

## D. Codex-Implementierungsauftrag

```text
Implementiere genau die freigegebene Verbesserung in einem eigenen Branch.
Ändere keine nicht betroffenen Komponenten. Ergänze Tests für Erfolg, Fehlerfall
und relevante Invarianten. Führe danach die vollständige Testsuite und denselben
Referenzbenchmark aus. Liefere Diff-Zusammenfassung, Testergebnisse, Vorher/Nachher-
Messung und bekannte Risiken. Merge nicht selbständig in main.
```

## E. Unabhängiger Review-Auftrag für Claude oder zweiten Codex-Lauf

```text
Prüfe diesen Branch unabhängig und zunächst read-only. Suche nach Logikfehlern,
Race Conditions, Nichtdeterminismus, falschen CivIdle-Annahmen, Datenvermischung,
Pfadverletzungen, unvollständigen Tests und irreführenden Benchmarks.

Bewerte jeden Befund nach Schweregrad und belege ihn mit Datei/Funktion/Test.
Verändere nichts. Übernimm keine Aussagen aus dem ursprünglichen Entwicklerbericht
ungeprüft.
```

## F. Strategie-Screening

```text
Vergleiche Kandidat und aktuellen Champion unter identischen Profilen, Seeds und
Limits. Verwirf Kandidaten mit Regelverletzung oder Instabilität. Berichte nicht
nur den schnellsten Lauf, sondern Median, Streuung, Fehlerrate und Zielmetriken.
Markiere Simulationswerte ausdrücklich als Simulation und nicht als reale
full_cycle_sec. Exportiere nur Kandidaten, die alle Freigaberegeln erfüllen.
```

## G. Realtest-Auftrag

```text
Teste nur den freigegebenen Kandidaten im echten Spielbot. Zuerst exakt drei
Screening-Runs. Nur bei 3/3 stabilen Läufen den Median full_cycle_sec mit dem
Champion vergleichen. Gewinnt der Kandidat, führe 20 Validierungsläufe aus.
Produktionsfreigabe nur bei 20/20 stabilen Läufen. Bei Abweichungen keine
automatische Reparatur am laufenden Bot, sondern Bericht und Rückfall.
```

## H. Nachtlauf mit Budget

```text
Starte einen isolierten Headless-Nachtlauf nur mit der ausdrücklich freigegebenen
Konfiguration. Grenze Laufzeit, CPU, RAM, Speicherplatz, Kandidatenzahl, Agenten-
schritte und Wiederholungen fest. Schreibe regelmässige Checkpoints und eine
Heartbeat-Datei. Stoppe sauber bei Limit, wiederholtem Fehler oder verletzter
Invariant. Keine Änderungen am laufenden Spielbot, Main-Save, Autostart oder
Updater. Erzeuge am Ende immer einen Bericht, auch nach Teilabbruch.
```

