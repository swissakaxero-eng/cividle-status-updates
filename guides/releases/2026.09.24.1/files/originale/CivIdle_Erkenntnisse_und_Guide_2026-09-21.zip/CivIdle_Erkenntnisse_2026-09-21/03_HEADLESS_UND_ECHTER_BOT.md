# Headless-Simulator und echter Spielbot

## Warum Headless schneller ist

Der echte Bot muss Bilder aufnehmen, Elemente erkennen, Mausbewegungen/Klicks ausführen, Animationen abwarten und auf das Spiel reagieren. Der Headless-Simulator berechnet nur Zustandsänderungen in Datenstrukturen. Er braucht keine Grafik, keine Maus und keine Animation.

Darum kann ein simulierter Lauf sehr viel schneller als ein echter Lauf sein.

## Was „ein Lauf in einer Sekunde“ wirklich bedeutet

Es bedeutet:

> Der Simulator hat die modellierten 600 Schritte oder den modellierten Fortschritt in einer Sekunde berechnet.

Es bedeutet nicht:

> Der reale Bildschirm-Bot erreicht dieselbe Spielstufe in einer Sekunde.

Die reale Mindestzeit bleibt von CivIdle, UI-Reaktionszeit, Animationen, Rendering, Erkennung und Sicherheitswartezeiten abhängig.

## Warum der Simulator trotzdem entscheidend ist

Angenommen, es existieren 20.000 mögliche Parameterkombinationen. Der echte Bot kann diese nicht sinnvoll vollständig ausprobieren. Der Simulator kann die grosse Menge vorsortieren. Danach müssen nur noch die besten und robustesten Kandidaten echt getestet werden.

Die Zahl „20.000 Läufe in wenigen Minuten“ ist ein mögliches Zielbild, **keine zugesicherte Leistung**. Die tatsächliche Geschwindigkeit muss gemessen werden und hängt von Modellkomplexität, Python-/Native-Code, Parallelität, Speicherzugriffen und Hardware ab.

## Richtige Aufgabenverteilung

| Aufgabe | Headless | Echter Bot |
|---|---:|---:|
| Tausende Strategien vergleichen | Ja | Nein |
| Zufallsseeds testen | Ja | Begrenzt |
| Produktions-/Kostenformeln prüfen | Ja | Zur Validierung |
| Klickpositionen lernen | Nein | Ja |
| Menüs/Bilder erkennen | Nein | Ja |
| UI-Wartezeiten messen | Nein | Ja |
| Reale Bronzezeit messen | Nur prognostizieren | Ja |
| `full_cycle_sec` verbindlich messen | Nein | Ja |
| Strategiekandidaten vorsortieren | Ja | Nein |
| Produktionsfreigabe | Mitwirkung | Entscheidend |

## Kalibrierung

Damit der Simulator nützlich bleibt, werden für gleiche Ausgangszustände Headless- und Realwerte verglichen:

- Ressourcen nach festen Schritten;
- Baukosten und Bauzeiten;
- Produktionsraten;
- Lager-/Transportgrenzen;
- Forschungskosten und Effekte;
- Great-Person-Multiplikatoren;
- Alterssprünge und Freischaltungen;
- Rebirth-Bedingungen;
- Zeit bis definierte Meilensteine.

Abweichungen werden versioniert dokumentiert. Ein schneller Kandidat wird nicht übernommen, wenn sein Vorteil nur aus einem Simulationsfehler entsteht.

## Unterschiedliche Accounts und Great Persons

Der Server-Mainaccount und eine lokale Testwelt müssen nicht denselben Fortschritt haben. Deshalb braucht der Simulator versionierte Profile, zum Beispiel:

```text
profile_clean_start.json
profile_server_gp_2026-09.json
profile_validation_fixed.json
```

Ein Profil enthält nur erlaubte, strukturierte Parameter. Der echte Main-Save wird dafür nicht geöffnet oder kopiert. Sensible oder unnötige Daten gehören nicht in den Simulator.

Strategien werden mindestens in zwei Kategorien bewertet:

1. **profilbezogen** – optimal für einen bestimmten GP-/Fortschrittsstand;
2. **robust** – gut über mehrere zulässige Profile und Seeds.

## Realtest-Gate

Nur Kandidaten, die alle Bedingungen erfüllen, dürfen zum echten Bot:

- keine Regel-/Invariantverletzung;
- reproduzierbarer Vorteil in mehreren Seeds;
- kein Vorteil durch bekannten Simulationsfehler;
- ausreichend viele Läufe;
- festgehaltene Konfiguration und Commit-ID;
- Vergleich gegen aktuellen Champion;
- klare Rückfallmöglichkeit.

