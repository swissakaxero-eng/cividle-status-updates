# CivIdle – Erkenntnisse, Werkzeugwahl und nächster Ausbau

Stand: 21. September 2026

Dieses Paket fasst die bisherigen Erkenntnisse zur Frage zusammen, ob es für das CivIdle-Projekt etwas Schnelleres oder Geeigneteres als einen normalen ChatGPT-Chat gibt.

## Kurzantwort

Ja – aber nicht als einzelner Ersatz für ChatGPT.

Der beste Aufbau für dieses Projekt ist:

1. **ChatGPT/Codex** für Planung, Codeänderungen, Tests und Auswertung.
2. **Privates GitHub-Repository** als einzige verbindliche Quelle für Code und Übergaben.
3. **CivIdle Headless** als Geschwindigkeitsmotor für sehr viele simulierte Strategietests.
4. **Echter Spielbot** nur für Kalibrierung und abschliessende Realtests.
5. **Codex SDK** später für die automatische Schleife aus Ändern, Testen, Bewerten und Behalten/Verwerfen.
6. **Claude Code** optional als unabhängiger Zweitprüfer.
7. **Cursor Cloud Agents** optional, wenn später noch mehr parallele Entwicklungsaufträge nötig sind.

Der grösste Engpass ist nicht die Intelligenz eines einzelnen Modells. Es sind die Übergaben per Chat/ZIP, fehlende automatische Rückkopplung und echte Spielruns in Echtzeit.

## Wichtigste Erkenntnis

Ein Headless-Lauf von beispielsweise einer Sekunde bedeutet **nicht**, dass der reale CivIdle-Bot die Bronzezeit in einer Sekunde erreicht. Es bedeutet nur, dass der Computer die modellierte Spielentwicklung so schnell berechnet hat.

Der Headless-Simulator beantwortet:

- Welche Strategie ist im Modell besser?
- Welche Reihenfolge sollte der Bot verwenden?
- Welche Parameter sind robust?
- Welche Varianten verdienen einen echten Spieltest?

Der echte Bot beantwortet:

- Stimmen Modell und reales Spiel überein?
- Funktionieren Erkennung, Klicks, Wartezeiten und Menüs?
- Wie schnell ist der reale Rebirth-to-Rebirth-Lauf?
- Bleibt die Strategie über viele echte Läufe stabil?

## Empfohlene Reihenfolge

### Jetzt

- Aktuellen Headless-Stand reproduzierbar testen.
- Referenz-Benchmark mit 1, 2 und 4 Testwelten und je 600 Schritten erfassen.
- Ergebnisformat, Zufallsseeds und Hardwaredaten festhalten.
- Simulator gegen bekannte CivIdle-Werte und wenige echte Läufe kalibrieren.
- Erst danach die Parallelität und Strategiensuche erhöhen.

### Danach

- Strategieparameter automatisch erzeugen.
- Kandidaten in mehreren Seeds prüfen.
- Gute Kandidaten in strengere Benchmarks übernehmen.
- Nur statistisch belastbare Verbesserungen behalten.
- Reale Spieltests als letzte Freigabestufe nutzen.

### Später

- Codex SDK als Entwicklungs-Orchestrator.
- Getrennte Agenten/Branches für Simulator, Tests, Daten und Review.
- Claude Code oder ein zweiter Codex-Lauf als unabhängige Kontrolle.
- Cursor Cloud Agents nur bei echtem Bedarf an zusätzlicher Cloud-Parallelität.

## Dateien in diesem Paket

- `01_WERKZEUGVERGLEICH.md` – was welches Werkzeug für CivIdle bringt.
- `02_KURZER_EINRICHTUNGSGUIDE.md` – Links und konkrete Schritte.
- `03_HEADLESS_UND_ECHTER_BOT.md` – Aufgabenverteilung und Grenzen.
- `04_ROADMAP_AUTOMATISCHE_OPTIMIERUNG.md` – Ausbau in sicheren Phasen.
- `05_SICHERHEIT_UND_TRENNUNG.md` – verbindliche Grenzen für Server und Main-Save.
- `06_AUFTRAGSVORLAGEN.md` – direkt kopierbare Aufträge für Codex, Review und Benchmarks.
- `07_MESSEN_STATT_RATEN.md` – Kennzahlen, Testregeln und Entscheidungskriterien.
- `08_OFFIZIELLE_LINKS.md` – geprüfte offizielle Einstiegsseiten.
- `CIVIDLE_AGENT_BRIEFING.md` – kompakte Übergabe für einen Coding-Agenten.
- `plan.json` – maschinenlesbare Phasen und Schutzregeln.

## Klare Empfehlung

Für den jetzigen Projektstand nichts unnötig umstellen und nicht fünf Systeme gleichzeitig einführen. Zuerst **Codex + GitHub + CivIdle_Headless** sauber schliessen. Claude und Cursor sind Ergänzungen, keine Voraussetzung.

