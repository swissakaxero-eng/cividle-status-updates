# CivIdle Agent Briefing

## Ziel

Das CivIdle-System soll Strategien schneller und zuverlässiger optimieren. Der Headless-Simulator dient als schnelles Versuchslabor; reale Botläufe bleiben die verbindliche Validierung.

## Einstieg

1. `project/START.md` lesen.
2. `project/HANDOFF_LATEST.json` lesen.
3. Nur direkt referenzierte aktuelle Übergaben lesen.
4. Commit, Branch, Tests und erlaubten Arbeitsbereich feststellen.
5. Vor Änderungen reproduzierbaren Ausgangslauf erzeugen.

## Harte Grenzen

- laufenden Spielbot nicht stoppen oder verändern;
- echten Main-Save nicht öffnen, kopieren oder verändern;
- keine bestehenden Tasks, Prozesse, Konfigurationen oder Logs bearbeiten/löschen;
- keine Installation in `CivIdle_Entwicklung` ohne neue Freigabe;
- kein Updater, Autostart oder Main-Snapshot;
- Headless-Ergebnisse nur unter `C:\CivIdle_Headless`;
- keine Zugangsdaten in Code, Log oder Ergebnis;
- kein selbständiger Merge in `main`.

## Aktueller sinnvoller Auftrag

1. Bestehenden Headless-Stand prüfen.
2. Tests unverändert ausführen.
3. Benchmark 1/2/4 Welten × 600 Schritte reproduzieren.
4. Rohdaten plus Bericht erzeugen.
5. Hotspots profilieren.
6. Eine kleine, belegte Optimierung pro Branch.
7. Tests und exakt gleichen Benchmark wiederholen.
8. Fachliche Gleichheit und statistischen Vorteil belegen.

## Qualitätsgate

Eine Änderung ist nur akzeptabel bei:

- vollständigen Tests;
- deterministischen Resultaten bei festen Seeds;
- keinen Invariant-/Pfadverletzungen;
- nachvollziehbarer Vorher/Nachher-Messung;
- Commit- und Konfigurationsreferenz;
- unabhängiger Review-Möglichkeit;
- sicherem Rückfall.

## Strategiefreigabe

- Simulation erzeugt Kandidaten, keine Produktionsfreigabe.
- Top-Kandidat: drei echte Screening-Runs.
- Nur 3/3 stabil und niedrigerer Median darf weiter.
- Sieger: 20 echte Validierungsläufe.
- Nur 20/20 stabil darf produktiv werden.

## Bericht am Ende jedes Auftrags

- Was wurde geprüft/geändert?
- Welche Dateien/Commits sind betroffen?
- Welche Tests liefen mit welchem Ergebnis?
- Welche Benchmarks liefen mit Rohdaten?
- Ist die Verbesserung grösser als Messrauschen?
- Welche Risiken und offenen Punkte bleiben?
- Wurde irgendeine harte Grenze berührt? Wenn ja: sofortiger Abbruch und genaue Meldung.

